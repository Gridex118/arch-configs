# Revision history for xmonad-alex

## 0.1.0.0 -- YYYY-mm-dd

* First version. Released on an unsuspecting world.
